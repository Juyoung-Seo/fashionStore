package fashion.store;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel="customerServices", path="customerServices")
public interface CustomerServiceRepository extends PagingAndSortingRepository<CustomerService, Long>{


}
