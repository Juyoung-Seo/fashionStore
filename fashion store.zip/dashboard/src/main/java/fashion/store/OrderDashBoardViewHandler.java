package fashion.store;

import fashion.store.config.kafka.KafkaProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class OrderDashBoardViewHandler {


    @Autowired
    private OrderDashBoardRepository orderDashBoardRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void whenOrdered_then_CREATE_1 (@Payload Ordered ordered) {
        try {

            if (!ordered.validate()) return;

            // view 객체 생성
            OrderDashBoard orderDashBoard = new OrderDashBoard();
            // view 객체에 이벤트의 Value 를 set 함
            orderDashBoard.setId(ordered.getId());
            orderDashBoard.setOrderId(ordered.getOrderId());
            orderDashBoard.setProductId(ordered.getProductId());
            orderDashBoard.setQty(ordered.getQty());
            orderDashBoard.setAddress(ordered.getAddress());
            orderDashBoard.setPaymentStatus(ordered.getPaymentStatus());
            orderDashBoard.setOrderStatus(ordered.getOrderStatus());
            orderDashBoard.setPrice(ordered.getPrice());
            // view 레파지 토리에 save
            orderDashBoardRepository.save(orderDashBoard);
        
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @StreamListener(KafkaProcessor.INPUT)
    public void whenOrderCancelled_then_UPDATE_1(@Payload OrderCancelled orderCancelled) {
        try {
            if (!orderCancelled.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(orderCancelled.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                orderDashBoard.setOrderStatus(orderCancelled.getOrderStatus());
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenOrderReturned_then_UPDATE_2(@Payload OrderReturned orderReturned) {
        try {
            if (!orderReturned.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(orderReturned.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                orderDashBoard.setOrderStatus(orderReturned.getOrderStatus());
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenPaymentApproved_then_UPDATE_3(@Payload PaymentApproved paymentApproved) {
        try {
            if (!paymentApproved.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(paymentApproved.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                orderDashBoard.setPaymentStatus(paymentApproved.getPaymentStatus());
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenPaymentCancelled_then_UPDATE_4(@Payload PaymentCancelled paymentCancelled) {
        try {
            if (!paymentCancelled.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(paymentCancelled.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                orderDashBoard.setPaymentStatus(paymentCancelled.getPaymentStatus());
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenDeliveyPrepared_then_UPDATE_5(@Payload DeliveyPrepared deliveyPrepared) {
        try {
            if (!deliveyPrepared.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(deliveyPrepared.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                orderDashBoard.setOrderStatus(deliveyPrepared.getOrderStatus());
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenDeliveryStarted_then_UPDATE_6(@Payload DeliveryStarted deliveryStarted) {
        try {
            if (!deliveryStarted.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(deliveryStarted.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                orderDashBoard.setOrderStatus(deliveryStarted.getOrderStatus());
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenDeliveryCancelled_then_UPDATE_7(@Payload DeliveryCancelled deliveryCancelled) {
        try {
            if (!deliveryCancelled.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(deliveryCancelled.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenOrderCompleted_then_UPDATE_8(@Payload OrderCompleted orderCompleted) {
        try {
            if (!orderCompleted.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(orderCompleted.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                orderDashBoard.setOrderStatus(orderCompleted.getOrderStatus());
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void whenOrderReturned_then_UPDATE_9(@Payload OrderReturned orderReturned) {
        try {
            if (!orderReturned.validate()) return;
                // view 객체 조회
            List<OrderDashBoard> orderDashBoardList = orderDashBoardRepository.findByOrderId(orderReturned.getOrderId());
            for(OrderDashBoard orderDashBoard : orderDashBoardList){
                // view 객체에 이벤트의 eventDirectValue 를 set 함
                orderDashBoard.setOrderStatus(orderReturned.getOrderStatus());
                // view 레파지 토리에 save
                orderDashBoardRepository.save(orderDashBoard);
            }
            
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}