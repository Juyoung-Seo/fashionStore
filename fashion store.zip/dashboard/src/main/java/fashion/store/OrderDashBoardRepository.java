package fashion.store;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface OrderDashBoardRepository extends CrudRepository<OrderDashBoard, Long> {

    List<OrderDashBoard> findByOrderId(Integer orderId);
    List<OrderDashBoard> findByOrderId(Integer orderId);
    List<OrderDashBoard> findByOrderId(Integer orderId);
    List<OrderDashBoard> findByOrderId(Integer orderId);
    List<OrderDashBoard> findByOrderId(Integer orderId);
    List<OrderDashBoard> findByOrderId(Integer orderId);
    List<OrderDashBoard> findByOrderId(Integer orderId);
    List<OrderDashBoard> findByOrderId(Integer orderId);
    List<OrderDashBoard> findByOrderId(Integer orderId);

}