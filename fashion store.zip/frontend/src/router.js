
import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router);


import ProductManager from "./components/ProductManager"

import OrderManager from "./components/OrderManager"

import PaymentManager from "./components/PaymentManager"

import DeliveryManager from "./components/deliveryManager"

import CustomerServiceManager from "./components/customerServiceManager"


import OrderDashBoard from "./components/orderDashBoard"
export default new Router({
    // mode: 'history',
    base: process.env.BASE_URL,
    routes: [
            {
                path: '/Product',
                name: 'ProductManager',
                component: ProductManager
            },

            {
                path: '/Order',
                name: 'OrderManager',
                component: OrderManager
            },

            {
                path: '/Payment',
                name: 'PaymentManager',
                component: PaymentManager
            },

            {
                path: '/delivery',
                name: 'deliveryManager',
                component: deliveryManager
            },

            {
                path: '/customerService',
                name: 'customerServiceManager',
                component: customerServiceManager
            },


            {
                path: '/orderDashBoard',
                name: 'orderDashBoard',
                component: orderDashBoard
            },


    ]
})
