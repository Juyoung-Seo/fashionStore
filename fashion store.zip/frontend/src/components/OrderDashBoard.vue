<template>

<v-data-table
    :headers="headers"
    :items="orderDashBoard"
    :items-per-page="5"
    class="elevation-1"
  ></v-data-table>

</template>

<script>
  const axios = require('axios').default;

  export default {
    name: 'OrderDashBoard',
    props: {
      value: Object,
      editMode: Boolean,
      isNew: Boolean
    },
    data: () => ({
        headers: [
            { text: "id", value: "id" },
            { text: "orderId", value: "orderId" },
            { text: "productId", value: "productId" },
            { text: "qty", value: "qty" },
            { text: "address", value: "address" },
            { text: "paymentStatus", value: "paymentStatus" },
            { text: "orderStatus", value: "orderStatus" },
            { text: "price", value: "price" },
        ],
        orderDashBoard : [],
    }),
    async created() {
      var temp = await axios.get(axios.backend + '/orderdashboards')

      this.orderDashBoard = temp.data._embedded.orderdashboards;

    },
    methods: {
    }
  }
</script>

