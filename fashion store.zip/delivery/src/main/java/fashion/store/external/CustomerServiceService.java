
package fashion.store.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Date;

@FeignClient(name="customerService", url="http://customerService:8080")
public interface CustomerServiceService {

    @RequestMapping(method= RequestMethod.GET, path="/customerServices")
    public void deliveryConfirm(@RequestBody CustomerService customerService);

}